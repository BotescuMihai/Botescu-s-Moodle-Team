/**
 * The Moodle.mod_quiz.util classes provide quiz-related utility functions.
 *
 * @module moodle-mod_quiz-util
 * @main
 */

Y.namespace('Moodle.mod_quiz.util');

/**
 * A collection of general utility functions for use in quiz.
 *
 * @class Moodle.mod_quiz.util
 * @static
 */
